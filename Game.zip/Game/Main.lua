-- المزرعة الاحترافية: نظام الحفظ + تأثيرات بصرية
function setup()
    -- 1. تحميل البيانات المحفوظة (أو وضع قيم افتراضية)
    money = readProjectData("save_money") or 500 
    xp = readProjectData("save_xp") or 0
    level = readProjectData("save_level") or 1
    xpNeeded = 100 * (1.5 ^ (level - 1))
    
    showStore = false 
    storeScroll = 0
    floatingTexts = {} -- قائمة للنصوص المتطايرة (+12$)
    
    -- 2. الطقس
    weather = 1
    weatherTimer = 0
    weatherNames = {"مشمس ☀️", "ممطر 🌧️", "غائم ☁️"}
    
    -- 3. الشبكة 8x8
    gridSize = 8
    cellSize = 45 
    gridStartX = 30
    gridStartY = (HEIGHT/2) - 180
    
    grid = {} 
    for r = 1, gridSize do
        grid[r] = {}
        for c = 1, gridSize do
            grid[r][c] = {plantType = nil, startTime = 0, watered = true}
        end
    end
    
    -- 4. قائمة الـ 20 نبتة (مع تحميل كمية البذور المحفوظة)
    inventory = {
        {name = "جزر", color = color(255, 120, 0), time = 10, buyPrice = 5, sellPrice = 12, minLevel = 1, xp = 10},
        {name = "تفاح", color = color(230, 30, 30), time = 20, buyPrice = 15, sellPrice = 35, minLevel = 1, xp = 20},
        {name = "خس", color = color(100, 255, 100), time = 30, buyPrice = 25, sellPrice = 60, minLevel = 2, xp = 35},
        {name = "بطاطس", color = color(190, 150, 100), time = 45, buyPrice = 40, sellPrice = 100, minLevel = 2, xp = 50},
        {name = "موز", color = color(240, 240, 50), time = 60, buyPrice = 60, sellPrice = 150, minLevel = 3, xp = 70},
        {name = "فراولة", color = color(255, 50, 80), time = 80, buyPrice = 100, sellPrice = 260, minLevel = 3, xp = 100},
        {name = "عنب", color = color(150, 50, 255), time = 120, buyPrice = 150, sellPrice = 400, minLevel = 4, xp = 150},
        {name = "برتقال", color = color(255, 165, 0), time = 150, buyPrice = 200, sellPrice = 550, minLevel = 5, xp = 200},
        {name = "جوز هند", color = color(120, 80, 40), time = 200, buyPrice = 300, sellPrice = 850, minLevel = 6, xp = 300},
        {name = "بطيخ", color = color(50, 200, 50), time = 300, buyPrice = 500, sellPrice = 1400, minLevel = 7, xp = 450},
        {name = "فطر", color = color(200, 180, 220), time = 400, buyPrice = 750, sellPrice = 2200, minLevel = 8, xp = 600},
        {name = "أناناس", color = color(255, 230, 100), time = 500, buyPrice = 1000, sellPrice = 3100, minLevel = 9, xp = 800},
        {name = "طماطم", color = color(255, 0, 0), time = 600, buyPrice = 1500, sellPrice = 4800, minLevel = 10, xp = 1100},
        {name = "كاكاو", color = color(80, 50, 20), time = 800, buyPrice = 2200, sellPrice = 7200, minLevel = 12, xp = 1500},
        {name = "دوار شمس", color = color(255, 220, 0), time = 1000, buyPrice = 3500, sellPrice = 11500, minLevel = 15, xp = 2000},
        {name = "خزامى", color = color(180, 100, 255), time = 1500, buyPrice = 5000, sellPrice = 18000, minLevel = 18, xp = 3000},
        {name = "دوريات", color = color(0, 255, 230), time = 2500, buyPrice = 8000, sellPrice = 30000, minLevel = 20, xp = 5000},
        {name = "ياقوت", color = color(255, 0, 100), time = 4000, buyPrice = 15000, sellPrice = 60000, minLevel = 25, xp = 8000},
        {name = "لوز أسطوري", color = color(255, 105, 180), time = 6000, buyPrice = 30000, sellPrice = 130000, minLevel = 30, xp = 15000},
        {name = "نبتة الحظ", color = color(255, 255, 255), time = 10000, buyPrice = 100000, sellPrice = 500000, minLevel = 50, xp = 50000}
    }
    
    for i, item in ipairs(inventory) do
        item.seeds = readProjectData("seeds_"..item.name) or (i <= 2 and 3 or 0)
    end
    
    selectedPlant = 1 
    sidebarWidth = 140 
end

function saveGame()
    saveProjectData("save_money", money)
    saveProjectData("save_xp", xp)
    saveProjectData("save_level", level)
    for _, item in ipairs(inventory) do
        saveProjectData("seeds_"..item.name, item.seeds)
    end
end

function draw()
    if weather == 1 then background(40, 80, 40)
    elseif weather == 2 then background(30, 50, 80)
    else background(60, 60, 65) end
    
    updateWeather()
    drawGrid()
    drawSidebar()
    drawTopUI()
    drawFloatingTexts()
    
    if showStore then drawStore() end
end

function updateWeather()
    weatherTimer = weatherTimer + 1
    if weatherTimer > 800 then 
        weather = math.random(1, 3)
        weatherTimer = 0
        if weather == 2 then 
            for r=1,gridSize do for c=1,gridSize do grid[r][c].watered = true end end
        end
    end
end

function drawGrid()
    pushMatrix()
    translate(gridStartX, gridStartY)
    local curTime = os.time()
    for r = 1, gridSize do
        for c = 1, gridSize do
            local x, y = (c-1)*cellSize, (r-1)*cellSize
            if grid[r][c].watered then fill(80, 50, 30) else fill(120, 90, 60) end
            stroke(50, 30, 10)
            rect(x, y, cellSize, cellSize)
            
            local cell = grid[r][c]
            if cell.plantType then
                local p = inventory[cell.plantType]
                local elapsed = curTime - math.floor(cell.startTime)
                
                if elapsed < p.time then
                    fill(120, 255, 120)
                    ellipse(x + cellSize/2, y + cellSize/2, 10)
                    if not cell.watered then
                        fill(0, 200, 255)
                        fontSize(15)
                        text("💧", x + cellSize/2, y + 25)
                        cell.startTime = cell.startTime + (1/60)
                    end
                else
                    -- تأثير النبض (Pulse Effect) عند النضوج
                    local pulse = math.sin(ElapsedTime * 10) * 3
                    fill(p.color)
                    rect(x+10-pulse/2, y+10-pulse/2, (cellSize-20)+pulse, (cellSize-15)+pulse)
                    fill(255, 215, 0)
                    text("$", x+cellSize/2, y+cellSize-10)
                end
            end
        end
    end
    popMatrix()
end

function drawTopUI()
    -- شريط XP
    fill(40)
    rect(20, HEIGHT - 100, WIDTH - 180, 20)
    fill(0, 220, 0)
    local xpProgress = xp/xpNeeded
    rect(20, HEIGHT - 100, math.min(1, xpProgress) * (WIDTH - 180), 20)
    fill(255)
    fontSize(14)
    text("ليفل "..level.." ("..math.floor(xp).."/"..math.floor(xpNeeded)..")", (WIDTH-180)/2, HEIGHT-90)
    
    -- ذهب وطقس
    fill(20, 20, 20, 180)
    rect(20, HEIGHT - 70, 300, 50)
    fill(255, 215, 0)
    text("الذهب: $"..money, 80, HEIGHT - 45)
    fill(180, 220, 255)
    text("الجو: "..weatherNames[weather], 220, HEIGHT - 45)
    
    -- زر متجر
    fill(34, 139, 34)
    rect(WIDTH - 130, HEIGHT - 70, 110, 50)
    fill(255)
    text("المتجر 🛒", WIDTH - 75, HEIGHT - 45)
end

function drawSidebar()
    local xStart = WIDTH - sidebarWidth
    fill(35)
    rect(xStart, 0, sidebarWidth, HEIGHT - 70)
    for i, item in ipairs(inventory) do
        local y = HEIGHT - 130 - (i-1) * 35
        if y > 20 then
            if selectedPlant == i then fill(80, 80, 140) else fill(50) end
            rect(xStart + 5, y - 15, sidebarWidth - 10, 30)
            fill(item.color)
            rect(xStart+10, y-8, 15, 15)
            fill(255)
            fontSize(11)
            text(item.name..": "..item.seeds, xStart + 80, y)
        end
    end
end

function drawFloatingTexts()
    for i = #floatingTexts, 1, -1 do
        local t = floatingTexts[i]
        fill(t.col.r, t.col.g, t.col.b, t.alpha)
        fontSize(18)
        text(t.txt, t.x, t.y)
        t.y = t.y + 1
        t.alpha = t.alpha - 3
        if t.alpha <= 0 then table.remove(floatingTexts, i) end
    end
end

function addFloatingText(txt, x, y, col)
    table.insert(floatingTexts, {txt = txt, x = x, y = y, col = col, alpha = 255})
end

function drawStore()
    fill(15, 15, 15, 250)
    rect(0, 0, WIDTH, HEIGHT)
    fill(255, 215, 0)
    fontSize(20)
    text("المتجر - اسحب للتمرير", WIDTH/2, HEIGHT-40)
    
    exitX, exitY = WIDTH-80, HEIGHT-70
    fill(150, 0, 0)
    rect(exitX, exitY, 60, 50)
    fill(255)
    text("X", exitX+30, exitY+25)
    
    pushMatrix()
    clip(0, 100, WIDTH, HEIGHT-120)
    translate(0, storeScroll)
    for i, item in ipairs(inventory) do
        local col, row = (i-1)%3, math.floor((i-1)/3)
        local x, y = 30 + col*210, HEIGHT-220 - row*100
        fill(45)
        rect(x, y, 190, 85)
        if level < item.minLevel then
            fill(180, 50, 50)
            text("مغلق ليفل "..item.minLevel, x+95, y+42)
        else
            fill(item.color)
            rect(x+10, y+55, 20, 20)
            fill(255)
            text(item.name, x+80, y+65)
            fill(255, 215, 0)
            text("$"..item.buyPrice, x+150, y+65)
            fill(0, 120, 0)
            rect(x+20, y+10, 150, 25)
            fill(255)
            text("شراء بذرة", x+95, y+22)
        end
    end
    popMatrix()
    clip()
end

function touched(touch)
    if touch.state == MOVING and showStore then storeScroll = storeScroll + touch.deltaY end
    if touch.state == BEGAN then
        if showStore then
            if touch.x > exitX and touch.y > exitY then showStore = false return end
            for i, item in ipairs(inventory) do
                local col, row = (i-1)%3, math.floor((i-1)/3)
                local x, y = 30 + col*210, HEIGHT-220 - row*100 + storeScroll
                if touch.x > x+20 and touch.x < x+170 and touch.y > y+10 and touch.y < y+35 then
                    if money >= item.buyPrice and level >= item.minLevel then
                        money = money - item.buyPrice
                        item.seeds = item.seeds + 1
                        saveGame() -- حفظ عند الشراء
                    end
                end
            end
            return
        end
        if touch.x > WIDTH-130 and touch.y > HEIGHT-70 then showStore = true return end
        if touch.x > WIDTH - sidebarWidth then
            for i = 1, #inventory do
                local y = HEIGHT - 130 - (i-1)*35
                if math.abs(touch.y-y) < 15 then selectedPlant = i end
            end
        else
            local col = math.ceil((touch.x - gridStartX) / cellSize)
            local row = math.ceil((touch.y - gridStartY) / cellSize)
            if row >= 1 and row <= gridSize and col >= 1 and col <= gridSize then
                local cell = grid[row][col]
                if not cell.plantType then
                    if inventory[selectedPlant].seeds > 0 then
                        inventory[selectedPlant].seeds = inventory[selectedPlant].seeds - 1
                        grid[row][col] = {plantType = selectedPlant, startTime = os.time(), watered = (weather==2)}
                        saveGame() -- حفظ عند الزراعة
                    end
                elseif not cell.watered then
                    cell.watered = true
                elseif (os.time() - math.floor(cell.startTime)) >= inventory[cell.plantType].time then
                    local p = inventory[cell.plantType]
                    money = money + p.sellPrice
                    xp = xp + p.xp
                    addFloatingText("+$"..p.sellPrice, touch.x, touch.y, color(255, 215, 0))
                    addFloatingText("+"..p.xp.." XP", touch.x, touch.y - 20, color(0, 255, 0))
                    if xp >= xpNeeded then
                        level = level + 1
                        xp = 0
                        xpNeeded = xpNeeded * 1.5
                    end
                    grid[row][col].plantType = nil
                    saveGame() -- حفظ عند الحصاد
                end
            end
        end
    end
end
